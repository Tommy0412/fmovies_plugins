jQuery(document).ready(function () {
	postboxes.add_postbox_toggles('wprc_metaboxes');
	jQuery('.if-js-closed').removeClass('if-js-closed').addClass('closed');
});