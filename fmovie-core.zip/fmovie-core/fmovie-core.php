<?php
/*
Plugin Name: Fmovie Core
Plugin URI: https://fr0zen.sellix.io/
Description: Fmovies WordPress Theme Core Plugin.
Version: 1.0.3
Author: fr0zen
Author URI: https://fr0zen.sellix.io/
*/
      

// remove
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10 );
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'feed_links_extra', 3); 
remove_action('wp_head', 'feed_links', 2); 
remove_action('wp_head', 'rsd_link'); 
remove_action('wp_head', 'wlwmanifest_link'); 
remove_action('wp_head', 'index_rel_link'); 
remove_action('wp_head', 'parent_post_rel_link', 10, 0); 
remove_action('wp_head', 'start_post_rel_link', 10, 0); 
remove_action('wp_head', 'adjacent_posts_rel_link', 10, 0);
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0);
remove_action('wp_head', 'wp_resource_hints', 2 );
//remove_action( 'admin_notices', 'update_nag', 3 );
remove_action('wp_head', 'print_emoji_detection_script', 7 );
remove_action('admin_print_scripts', 'print_emoji_detection_script' );
remove_action('wp_print_styles', 'print_emoji_styles' );
remove_action('admin_print_styles', 'print_emoji_styles' );
remove_action('wp_head', 'rest_output_link_wp_head', 10 );
add_filter( 'wpseo_json_ld_output', '__return_false' );
add_filter( 'gutenberg_use_widgets_block_editor', '__return_false', 100 );
add_filter( 'use_widgets_block_editor', '__return_false' );
define	('client', 'lol'); 
//next_rel_link
add_filter( 'wpseo_next_rel_link', '__return_false' );
add_filter( 'wpseo_prev_rel_link', '__return_false' );

function taxonomy_init()
{
    register_taxonomy('director', 'post', array(
            'hierarchical' => false, 'label' => 'Directors',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('actors', 'post', array(
            'hierarchical' => false, 'label' => 'Actors',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('country', 'post', array(
            'hierarchical' => false, 'label' => 'Countries',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('years', 'post', array(
            'hierarchical' => false, 'label' => 'Year',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('language', 'post', array(
            'hierarchical' => false, 'label' => 'Language',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('quality', 'post', array(
            'hierarchical' => false, 'label' => 'Quality',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('networks', 'post', array(
            'hierarchical' => false,  'label' => 'Networks',
            'query_var' => true, 'rewrite' => true));
    register_taxonomy('creator', 'post', array(
             'hierarchical' => false,  'label' => 'Creators',
             'query_var' => true, 'rewrite' => true));
    } 
add_action('init', 'taxonomy_init', 0);

function unregister_default_widgets() {
unregister_widget('WP_Widget_Block');
unregister_widget('WP_Nav_Menu_Widget');
unregister_widget('WP_Widget_Media_Audio');
unregister_widget('WP_Widget_Media_Image');
unregister_widget('WP_Widget_Media_Video');
unregister_widget('WP_Widget_Media_Gallery');
unregister_widget('WP_Widget_RSS');
unregister_widget('WP_Widget_Calendar');
unregister_widget('WP_Widget_Search');
unregister_widget('WP_Widget_Tag_Cloud');
}
add_action('widgets_init', 'unregister_default_widgets', 11);

function wpdocs_remove_menus(){

  remove_submenu_page( 'themes.php', 'nav-menus.php' );  //Nav Menu

   
}
add_action( 'admin_menu', 'wpdocs_remove_menus' );


//Enable upload webp images
function webp_upload_mimes( $existing_mimes ) {
    // add webp to the list of mime types
    $existing_mimes['webp'] = 'image/webp';

    // return the array back to the function with our added mime type
    return $existing_mimes;
}
add_filter( 'mime_types', 'webp_upload_mimes' );
	
	
//Enable preview / thumbnail for webp images
function webp_is_displayable($result, $path) {
    if ($result === false) {
        $displayable_image_types = array( IMAGETYPE_WEBP );
        $info = @getimagesize( $path );

        if (empty($info)) {
            $result = false;
        } elseif (!in_array($info[2], $displayable_image_types)) {
            $result = false;
        } else {
            $result = true;
        }
    }

    return $result;
}
add_filter('file_is_displayable_image', 'webp_is_displayable', 10, 2);



/**
//load jQuery 3.5.1 cdn
add_action( 'wp_enqueue_scripts', function(){
    if (is_admin()) return; 
    wp_deregister_script( 'jquery' );
    wp_register_script( 'jquery', 'https://cdn.jsdelivr.net/npm/jquery@3.6.1/dist/jquery.min.js', array(), '3.6.1', false );
    wp_enqueue_script( 'jquery');
});

//remove mograte min
add_action( 'wp_default_scripts', function( $scripts ) {
    if ( ! empty( $scripts->registered['jquery'] ) ) {
        $scripts->registered['jquery']->deps = array_diff( $scripts->registered['jquery']->deps, array( 'jquery-migrate' ) );
    }
  } 
);

//lol
function theme_scripts() {
  wp_enqueue_script('jquery');
}
add_action('wp_enqueue_scripts', 'theme_scripts');
 */
 
function modify_footer() { ?>
<?php echo __('Created by ', 'fmovie'); ?><a href="<?php echo esc_url( __( 'https://fr0zen.sellix.io/', 'fmovie' ) ); ?>" target="_blank"><?php printf( __( 'fr0zen %s', 'fmovie' ),''); ?></a>
<?php }
add_filter( 'admin_footer_text', 'modify_footer' );
 
 
 
 
add_action( 'wp_enqueue_scripts', 'fmovie_child_deregister_styles', 20 );
function fmovie_child_deregister_styles() {
    wp_dequeue_style( 'classic-theme-styles' );

}

function fmovie_attach_external_image( $url = null, $post_id = null, $thumb = null, $filename = null, $post_data = array() ) {
    if ( !$url || !$post_id ) return new WP_Error('missing', "Need a valid URL and post ID...");
    require_once( ABSPATH . 'wp-admin/includes/file.php' );

    $tmp = download_url( $url );


    if ( is_wp_error( $tmp ) ) {
        @unlink($file_array['tmp_name']);   
        $file_array['tmp_name'] = '';
        return $tmp; 
    }

    preg_match('/[^\?]+\.(jpg|JPG|jpe|JPE|jpeg|JPEG|gif|GIF|png|PNG)/', $url, $matches);    
    $url_filename = $post_id.'-poster.jpg';                                               
    $url_type = wp_check_filetype($url_filename);                                         


    if ( !empty( $filename ) ) {
        $filename = sanitize_file_name($filename);
        $tmppath = pathinfo( $tmp );                                                        
        $new = $tmppath['dirname'] . "/". $filename . "." . $tmppath['extension'];          
        rename($tmp, $new);                                                                
        $tmp = $new;                                                                        
    }


    $file_array['tmp_name'] = $tmp;                                                         

    if ( !empty( $filename ) ) {
        $file_array['name'] = $filename . "." . $url_type['ext'];                         
    } else {
        $file_array['name'] = $url_filename;                                               
    }


    if ( empty( $post_data['post_title'] ) ) {
        $post_data['post_title'] = basename($url_filename, "." . $url_type['ext']);        
    }


    if ( empty( $post_data['post_parent'] ) ) {
        $post_data['post_parent'] = $post_id;
    }


    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');


    $att_id = media_handle_sideload( $file_array, $post_id, null, $post_data );             


    if ( is_wp_error($att_id) ) {
        @unlink($file_array['tmp_name']);   
        return $att_id; 
    }


    if ($thumb) {
        set_post_thumbnail($post_id, $att_id);
    }

    return $att_id;
}


add_action( 'admin_init', 'url_to_image_custome_field' );
 
function url_to_image_custome_field() {
    add_meta_box(
	'url_to_image_meta_box', 
	'Poster',
	'url_to_image_meta_box', 
	'post',
	'side',
	'low'
	);
}
 
function url_to_image_meta_box () {
 

echo '<input type="hidden" name="poster-image-url-nonce" id="poster-image-url-nonce" value="' .
wp_create_nonce( 'poster-image-url-nonce' ) . '" />';
?>
<div class="poster_meta_box">
<ul>
<li><input placeholder="Poster url" class="poster_input_box" name="image_url" value=""></li>
</ul>
</div>
<?php
}

function url_to_image_fmovie_field(){
global $post;
 
$post_id =  $post->ID;


 
if ( !wp_verify_nonce( $_POST['poster-image-url-nonce'], 'poster-image-url-nonce' )) {
    return $post->ID;
}
if ( !current_user_can( 'edit_post', $post->ID )) {
    return $post->ID;
} 
if(!isset($_POST["image_url"])){
	return $post->ID;
}
$image_url 	= 	strip_tags($_POST["image_url"]);
$upload_img =	fmovie_attach_external_image( $image_url,$post->ID,get_the_title($post->ID));
}
add_action ('post_updated', 'url_to_image_fmovie_field');

//encodeUrl
function encodeUrl($url) {
 global $post;
 return urlencode( base64_encode( $url ) );
}

//report_content
function report_content() {
global $post;
if (!function_exists('is_plugin_active')) {
    include_once(ABSPATH . 'wp-admin/includes/plugin.php');
}
if ( is_plugin_active( 'report-content/report-content.php' ) ) {
    echo wprc_report_submission_form();
} else {
//null
} 
}

//credits
function credits() {
global $post;
echo '<p>';
printf(
/* translators: %s: WordPress. */
esc_html__( 'WordPress Theme created by %s', 'fmovie' ),
'<a class="text-primary" title="fr0zen wordpress themes" href="' . esc_url( __( 'https://fr0zen.mysellix.io', 'fmovie' ) ) . '">fr0zen</a>');
echo '</p>';
}